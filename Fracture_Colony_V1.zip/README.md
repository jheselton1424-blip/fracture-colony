# Fracture Colony — playable prototype

Open `index.html` in a modern browser. The prototype is designed for an iPhone-sized screen and saves progress locally.

This first vertical slice demonstrates:
- decision-first colony storytelling
- four choices per event
- persistent colony resources and colonists
- delayed/story flags
- visible character marks caused by decisions
- animated atmospheric event presentation
- local save persistence

The next expansion can add dozens of conditional events, longer chains, procedural characters, factions, relationships, injuries, transformations, and richer scene art.
